var searchData=
[
  ['quitgame',['quitGame',['../classUserGame.html#a0c375eaf2b4d663e03e0862b32524018',1,'UserGame']]],
  ['quitmessage',['QuitMessage',['../classPlayerCommunication.html#af753373a47ed01359c61402cb2032a1f',1,'PlayerCommunication']]]
];
