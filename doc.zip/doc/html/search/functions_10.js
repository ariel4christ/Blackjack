var searchData=
[
  ['validsplit',['validSplit',['../classBankCommunication.html#a02829f086df54ffd41d4018039770947',1,'BankCommunication']]],
  ['validstand',['validStand',['../classBankCommunication.html#a4601b9305fac30332d539203d74020ed',1,'BankCommunication']]],
  ['validsurrender',['validSurrender',['../classBankCommunication.html#a20377fc6ff851ca9c2332fcb0a2272b5',1,'BankCommunication']]]
];
