var searchData=
[
  ['trandfersecondcard',['trandferSecondCard',['../classHand.html#a98ffc207f2c18384f23881f0746c9503',1,'Hand']]]
];
