var searchData=
[
  ['operator_3d',['operator=',['../classCard.html#af481bbabadc856589856c637395ad25b',1,'Card']]]
];
