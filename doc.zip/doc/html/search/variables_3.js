var searchData=
[
  ['stand',['stand',['../classPlayerHand.html#a070529a8fd3ac6da30c5a98f63a63876',1,'PlayerHand']]]
];
