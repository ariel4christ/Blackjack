var searchData=
[
  ['hand',['hand',['../classPlayer.html#a32869ca4c82cd4c1eb8e277c4c595240',1,'Player']]],
  ['hand2',['hand2',['../classPlayer.html#ad7e7a6e96322a1b3183ce85d57c1c39b',1,'Player']]]
];
